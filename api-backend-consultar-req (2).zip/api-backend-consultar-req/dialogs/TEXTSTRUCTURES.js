
const TEXTS = {
    BOTNAME: '👩‍💻Soy Mercurio *tu asistente virtual.*',
    SALUDAR: '!Hola! Bienvenido, en que puedo ayudarte\n',
    DESPEDIDA_USUARIO_INACTIVO:'Adios'
  };
  
  exports.TEXTS = TEXTS;